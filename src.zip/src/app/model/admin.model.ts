import { User } from "./user.model";

export class Admin{
    id?: number;
    name?: string;
    user?: User;
  }