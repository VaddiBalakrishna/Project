import { User } from "./user.model";

export class Customer{
  id?: number;
  name?: string;
  companyName?:string;
  user?: User;
  email?: string;
  mobileNo?: number;
  panCard?: string;
  username?: User;
}
