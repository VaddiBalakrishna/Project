import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-arta-main',
  templateUrl: './arta-main.component.html',
  styleUrls: ['./arta-main.component.scss']
})
export class ARTAMainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
